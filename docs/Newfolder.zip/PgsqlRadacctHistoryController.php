<?php

namespace App\Http\Controllers;

use App\Models\pgsql\pgsql_radacct_history;
use Illuminate\Http\Request;

class PgsqlRadacctHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\pgsql_radacct_history  $pgsql_radacct_history
     * @return \Illuminate\Http\Response
     */
    public function show(pgsql_radacct_history $pgsql_radacct_history)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\pgsql_radacct_history  $pgsql_radacct_history
     * @return \Illuminate\Http\Response
     */
    public function edit(pgsql_radacct_history $pgsql_radacct_history)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\pgsql_radacct_history  $pgsql_radacct_history
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, pgsql_radacct_history $pgsql_radacct_history)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\pgsql_radacct_history  $pgsql_radacct_history
     * @return \Illuminate\Http\Response
     */
    public function destroy(pgsql_radacct_history $pgsql_radacct_history)
    {
        //
    }
}

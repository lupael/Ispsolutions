<?php

namespace App\Http\Controllers;

use App\Models\cash_in;
use Illuminate\Http\Request;

class CashInController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\cash_in  $cash_in
     * @return \Illuminate\Http\Response
     */
    public function show(cash_in $cash_in)
    {
        $transaction = $cash_in->transaction;

        if ($transaction == false) {
            return "No Details";
        }
        return view('admins.components.cash_in_details', [
            'transaction' => $transaction,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\cash_in  $cash_in
     * @return \Illuminate\Http\Response
     */
    public function edit(cash_in $cash_in)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\cash_in  $cash_in
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, cash_in $cash_in)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\cash_in  $cash_in
     * @return \Illuminate\Http\Response
     */
    public function destroy(cash_in $cash_in)
    {
        //
    }
}

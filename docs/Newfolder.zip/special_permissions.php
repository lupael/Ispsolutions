<?php

return [
    'edit-package-price',
    'edit-customer-payment',
    'delete-customer-payment',
    'edit-bills',
    'delete-bills',
    'discount-on-bills',
    'set-special-price-for-customer',
    'reseller-module',
    'delete-customer',
    'edit-customers-billing-profile',
];

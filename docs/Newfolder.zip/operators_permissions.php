<?php

return [
    'Dashboard',
    'view-customer-details',
    'view-online-customers',
    'view-offline-customers',
    'create-customer',
    'edit-customer',
    'activate-customer',
    'suspend-customer',
    'disable-customer',
    'change-customer-package',
    'receive-payment',
    'print-invoice',
    'generate-bill',
    'send-sms',
    'expense-management',
    'view-customer-payments',
];

<?php

return [
    'zone_id' => 'Zone',
    'name' => 'Name',
    'mobile' => 'Mobile',
    'email' => 'Email',
    'house_no' => 'House No',
    'road_no' => 'Road No',
    'thana' => 'Thana',
    'district' => 'District',
    'nid' => 'NID',
    'date_of_birth' => 'Date of Birth',
];
